

export class Feedback {
    constructor(empId: any, empName: any,
        projectName: any, rating: any, comments: any, mgrRating: any, mgrComments) { }
}
